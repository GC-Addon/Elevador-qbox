return {
    key = 38, -- E

    texts = {
        open = '[E] - Elevator'
    },

    interact_dist = 1.5,

    elevators = {
        ['Juridico'] = {
            {
                number = 0, -- floor
                name = 'Térreo', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-535.2, 1159.02, 325.53),
            },
            {
                number = 0, -- floor
                name = 'Térreo', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-542.47, 1167.02, 325.53),
            },
            {
                number = 1, -- floor
                name = 'Primeiro andar', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-532.93, 1155.96, 337.28),
            },
            {
                number = 2, -- floor
                name = 'Segundo andar', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-532.92, 1155.95, 347.37),
            },

            
            {
                number = 3, -- floor
                name = 'Tribunal', -- or false
                code = '1234', -- restrict floor by password
                pos = vector3(-532.96, 1155.86, 355.7),
            },
            {
                number = 4, -- floor
                name = 'Teto', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-532.97, 1155.86, 363.28),
            },
            
        },

        
        ['Vanilla'] = {
            {
                number = 0, -- floor
                name = 'Boate', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(118.76, -1261.9, 21.81)
            },
            {
                number = 1, -- floor
                name = 'Motel', -- or false
                code = '1234', -- restrict floor by password
                pos = vector3(129.92, -1284.42, -85.22),
            },
            
        },

        ['Life Invader'] = {
            {
                number = 0, -- floor
                name = 'Térreo', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-1072.81, -246.69, 54.01)
            },
            {
                number = 1, -- floor
                name = 'Primeiro andar', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-1078.06, -254.56, 44.02),
            },
            {
                number = 2, -- floor
                name = 'Teto', -- or false
                code = '1234', -- restrict floor by password
                pos = vector3(-1072.81, -246.69, 54.01),
            },
            
        },

        ['Example'] = {
            {
                number = 0, -- floor
                name = false, -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-1067.68, -284.49, 37.71),
            },
            {
                number = 1, -- floor
                name = 'Roof', -- or false
                code = nil, -- restrict floor by password
                pos = vector3(-1066.94, -286.98, 50.02),
            },
        },
    },
}